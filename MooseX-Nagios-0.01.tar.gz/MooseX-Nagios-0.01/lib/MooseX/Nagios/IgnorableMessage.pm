package MooseX::Nagios::IgnorableMessage;

use Moose::Role;

sub match_keys { }
sub ok { 1 }

1;
